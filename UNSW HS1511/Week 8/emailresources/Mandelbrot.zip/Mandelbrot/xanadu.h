/*
 * xanadu.h
 * defines the centre of your beautiful colored tile image of the mandelbrot set
 * team members names here:
 * your description here:
 */
 
// replace these three values with your own chosen numbers
 #define CENTER_X -0.6509289247915151
 #define CENTER_Y 0.4351990763403009
 #define ZOOM 16